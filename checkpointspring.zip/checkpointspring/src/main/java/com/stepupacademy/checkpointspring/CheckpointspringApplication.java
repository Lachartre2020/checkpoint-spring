package com.stepupacademy.checkpointspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckpointspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckpointspringApplication.class, args);
	}

}
